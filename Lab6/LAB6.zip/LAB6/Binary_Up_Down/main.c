//declare header files here
#include <LPC17xx.h>


//declare variables here
unsigned int i,j;
unsigned long ADD;
unsigned long x;

//main function starts here
int main(void)
{
	SystemInit();
	SystemCoreClockUpdate();
	
	LPC_PINCON ->PINSEL0 = 0x00000000;
	LPC_GPIO0 ->FIODIR |= 0xFF;	
	
	//Setting value to input
	LPC_PINCON ->PINSEL4 = 0x00000000;
	LPC_GPIO2 ->FIODIR |= 0xFF000000;
	
	
	//Setting switching direction
	LPC_GPIO2 -> FIOPIN = 0x1000;
	//LPC_GPIO2 -> FIOMASK = 0x1000;
	
	
	//CNB pin 7, P2.12

	
	while(1)
	{
		x = LPC_GPIO2 -> FIOPIN;
		x>>=12;
		x = x&1;
		
		if(x == 1)
		{
			ADD = 0x00;
			for(j=0;j<256;j++)
			{
				LPC_GPIO0 -> FIOPIN = ADD;
				for(i=0;i<50000;i++);
				ADD += 0x1;
			}
		}
		
		else if (x==0)
		{
			ADD = 0xFF;
			//LPC_GPIO0 -> FIOPIN = ADD;
			for(j=0;j<256;j++)
			{
				LPC_GPIO0 -> FIOPIN = ADD;
				for(i=0;i<50000;i++);
				ADD -= 0x1;
			}
		}
		
		
		
	}
	
}