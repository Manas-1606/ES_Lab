//declare header files here
#include <LPC17xx.h>


//declare variables here
unsigned int i,j;
unsigned long ADD;

//main function starts here
int main(void)
{
	SystemInit();
	SystemCoreClockUpdate();
	
	LPC_PINCON ->PINSEL0 = 0x0;
	LPC_GPIO0 ->FIODIR |= 0xFF;	
	
	while(1)
	{
		ADD = 0x00;
		for(j=0;j<256;j++)
		{
			LPC_GPIO0 -> FIOPIN = ADD;
			for(i=0;i<50000;i++);
			ADD += 0x1;
		}
		
		
	}
	
}