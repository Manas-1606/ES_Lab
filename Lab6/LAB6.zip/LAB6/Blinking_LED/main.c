//declare header files here
#include <LPC17xx.h>


//declare variables here
unsigned int i;


//main function starts here
int main(void)
{
	SystemInit();
	SystemCoreClockUpdate();
	
	LPC_PINCON ->PINSEL0 = 0x0;
	LPC_GPIO0 ->FIODIR |= 0x10;	
	
	while(1)
	{
		LPC_GPIO0 -> FIOSET = 0x10;
		for(i=0;i<100000;i++);
		LPC_GPIO0 -> FIOCLR = 0x10;
		for(i=0;i<100000;i++);
	}
	
}

