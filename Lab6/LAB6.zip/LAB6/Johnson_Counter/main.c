//declare header files here
#include <LPC17xx.h>


//declare variables here
unsigned int i,j;
unsigned long ADD;

//main function starts here
int main(void)
{
	SystemInit();
	SystemCoreClockUpdate();
	
	LPC_PINCON ->PINSEL0 = 0x0;
	LPC_GPIO0 ->FIODIR |= 0xFF;	
	
	while(1)
	{
		ADD = 0x80;
		for(j=0;j<8;j++)
		{
			LPC_GPIO0 -> FIOSET = ADD;
			for(i=0;i<100000;i++);
			//LPC_GPIO0 -> FIOCLR = ADD;
			ADD>>=1;					
		}
		
		ADD = 0x80;
		for(j=0;j<8;j++)
		{
			LPC_GPIO0 -> FIOCLR = ADD;
			for(i=0;i<100000;i++);
			//LPC_GPIO0 -> FIOCLR = ADD;
			ADD>>=1;					
		}
		
		
	}
	
}